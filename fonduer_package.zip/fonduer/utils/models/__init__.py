from fonduer.utils.models.annotation import AnnotationKeyMixin, AnnotationMixin

__all__ = ["AnnotationKeyMixin", "AnnotationMixin"]
